cd deploy/k8s/
bash start.sh
cd ../../
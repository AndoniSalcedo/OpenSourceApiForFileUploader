cd deploy/k8s
kubectl delete -f .
cd ../../
package es.uv.andoni.mongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDataApplication {

  public static void main(String[] args) {
    SpringApplication.run(MongoDataApplication.class, args);
  }
}

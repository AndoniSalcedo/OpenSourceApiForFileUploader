kubectl delete -f mongo-statefulset.yml 
kubectl delete -f rabbit-deployment.yml
kubectl delete -f mysql-statefulset.yml 
